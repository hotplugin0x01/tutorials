# Run from widget-app directory
rm ../dashboard-app.zip
zip -r ../dashboard-app.zip *
